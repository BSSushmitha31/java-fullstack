package MapEg;

import java.util.HashSet;

public class HashMapeg {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet hashset = new HashSet();
		hashset.add(25);
		hashset.add(35);
		hashset.add("sush");
		System.out.println(hashset);

}
}
