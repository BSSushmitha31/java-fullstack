package MapEg;

import java.util.LinkedHashSet;

public class LinkedHasheg {
	public static void main(String[] args)
	{
		LinkedHashSet linkedHashSet = new LinkedHashSet();
		linkedHashSet .add(25);
		linkedHashSet .add(80);
		linkedHashSet.add("anu");
		System.out.println(linkedHashSet);
	}
}
