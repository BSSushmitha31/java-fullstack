package Program5;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Collection {
	 public static void main(String[] args) {
	        // Create an ArrayList
	        List<String> arrayList = new ArrayList<>();
	        arrayList.add("Apple");
	        arrayList.add("Banana");
	        arrayList.add("Orange");

	        // Create a LinkedList
	        List<String> linkedList = new LinkedList<>();
	        linkedList.add("Apple");
	        linkedList.add("Banana");
	        linkedList.add("Orange");

	        // Perform common operations on collections
	        System.out.println("ArrayList: " + arrayList);
	        System.out.println("LinkedList: " + linkedList);
	        System.out.println();

	        // Add an element at a specific index
	        arrayList.add(1, "Mango");
	        linkedList.add(1, "Mango");

	        // Remove an element by value
	        arrayList.remove("Banana");
	        linkedList.remove("Banana");

	        // Get an element by index
	        String element1 = arrayList.get(2);
	        String element2 = linkedList.get(2);

	        // Check if a collection contains a value
	        boolean contains1 = arrayList.contains("Apple");
	        boolean contains2 = linkedList.contains("Apple");

	        // Check the size of a collection
	        int size1 = arrayList.size();
	        int size2 = linkedList.size();

	        // Display the results
	        System.out.println("ArrayList: " + arrayList);
	        System.out.println("LinkedList: " + linkedList);
	        System.out.println();

	        System.out.println("Element at index 2 (ArrayList): " + element1);
	        System.out.println("Element at index 2 (LinkedList): " + element2);
	        System.out.println();

	        System.out.println("ArrayList contains 'Apple': " + contains1);
	        System.out.println("LinkedList contains 'Apple': " + contains2);
	        System.out.println();

	        System.out.println("Size of ArrayList: " + size1);
	        System.out.println("Size of LinkedList: " + size2);
	    }
}
