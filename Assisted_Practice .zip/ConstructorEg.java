package Program4;

public class ConstructorEg {
		String sname;
		int snum;
	ConstructorEg(String a, int b)
	{
		sname= a;
		snum = b;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ConstructorEg c1 = new ConstructorEg("sush",101);
		System.out.println(c1.sname);
		System.out.println(c1.snum);
	}

}
