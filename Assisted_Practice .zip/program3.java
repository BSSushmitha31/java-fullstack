package Phase1;

public class program3 
{

//	public int addition(int a,int b) 
//	{
//		int result=a+b;
//		return result;
//	}

//	public static void main(String[] args) 
//	{
//		program3 b=new program3();
//		int ans= b.addition(5,6);
//		System.out.println("Addition of 2 numbers is :"+ans);
//	}
	
	//call by value
//	public  class callMethod 
	//{

//	int n=15;
//
//	int mul(int n) 
//	{
//		n =n*10;
//		return(n);
//	}
//	public static void main(String args[]) {
//		program3 d = new program3();
//		System.out.println("Before operation value of data is "+d.n);
//		d.mul(100);
//		System.out.println("After operation value of data is "+d.n);
//		}
//
//	}


//Method overloading


  void add (int a, int b)
  {
    System.out.println("addition of 2 number "+(a+b)) ;
  }
  void add (float a, float b)
  {
    System.out.println("addition of 2 numbers "+(a+b));
  }
  public static void main (String[] args)
  {
	  program3  pro = new program3();
	  pro.add (8,8);     
	  pro.add (1.6f, 3.8f); 
  }
}

	


