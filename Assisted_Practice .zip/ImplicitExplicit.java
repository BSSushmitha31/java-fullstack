package Phase1;

public class ImplicitExplicit {

	public static void main(String[] args) {

		 // Implicit Type Casting
        int n1 = 10;
        double n2 = n1; // Implicitly casting int to double
        System.out.println("Implicit Casting (int to double) : " + n2);

        // Explicit Type Casting
        double n3 = 5.45;
        int n4 = (int) n3; // Explicitly casting double to int
        System.out.println("Explicit Casting (double to int) : " + n4);
	}

}
