package Phase1;

public class AccessModifiers {

	public static void main(String[] args) {
		
		 // Creating an instance of the AccessModif class
		AccessModif am = new AccessModif();

        // Accessing public variable and method
		am.pub = 10;
        am.pub();

        // Accessing protected variable and method
        am.prot = 20;
        am.prot();

        // Accessing default variable and method
        am.def = 30;
        am.def();

	}

}

class AccessModif {
    public int pub;
    protected int prot;
    int def;
    private int priv;

    public void pub() {
        System.out.println("Public method "+ pub);
    }

    protected void prot() {
        System.out.println("Protected method "+ prot);
    }

    void def() {
        System.out.println("Default method "+ def);
    }

    private void priv() {
        System.out.println("Private method");
    }
}
