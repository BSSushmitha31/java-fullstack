package Program9;

public class Arrayeg {

	public static void main(String[] args) {
		
		  // Single-dimensional array
        int[] numbers = { 1, 2, 3, 4, 5 };
        System.out.println("Single-dimensional array:");
        for (int i = 0; i < numbers.length; i++) 
        {
            System.out.println(numbers[i]);
        }

        // Multi-dimensional array
        int[][] matrix = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };  
        System.out.println("\nMulti-dimensional array:");
        for (int row = 0; row < matrix.length; row++) 
        {
            for (int col = 0; col < matrix[row].length; col++) 
            {
                System.out.print(matrix[row][col] + " ");
            }
            System.out.println();
        }
	}

}
