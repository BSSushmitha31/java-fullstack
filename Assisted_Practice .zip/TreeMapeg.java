package MapEg;

import java.util.TreeSet;

public class TreeMapeg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet treeSet = new TreeSet();
		treeSet.add(36);
		treeSet.add(25);
		treeSet.add(80);
		System.out.println(treeSet);
	}

}
