import { Component } from '@angular/core';
import { AuthService } from '../auth.service'; 
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {
  email: string = '';
  password: string = '';

  constructor(private authService: AuthService) {}

  signUp(): void {
    this.authService.signUp(this.email, this.password)
      .then(success => {
        if (success) {
          console.log('Registration successful');
          // Optionally, navigate to another page upon successful registration.
        } else {
          console.log('Registration failed');
        }
      });
  }
}
