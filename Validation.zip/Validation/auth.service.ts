import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  signUp(email: string, password: string): Promise<boolean> {
    // Simulate successful registration for demonstration purposes.
    return Promise.resolve(true);
  }
}
