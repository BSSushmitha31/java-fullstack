package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DatabaseServlet")

public class DatabaseServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String jdbcUrl = "jdbc:mysql://localhost:3306/";
        String username = "root";
        String password = "root";
        String databaseName = "CreateDatabase";

        try {
            // Step 1: Register the JDBC driver (if necessary)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Step 2: Open a connection to the server
            Connection connection = DriverManager.getConnection(jdbcUrl, username, password);

            // Step 3: Create a new database
            Statement statement = connection.createStatement();
            statement.executeUpdate("CREATE DATABASE " + databaseName);
            out.println("Database created successfully!");

            // Step 4: Use the newly created database
            statement.executeUpdate("USE " + databaseName);
            out.println("Using database: " + databaseName);

            // Step 5: Drop the database
            statement.executeUpdate("DROP DATABASE " + databaseName);
            out.println("Database dropped successfully!");

            // Step 6: Close the resources
            statement.close();
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}
