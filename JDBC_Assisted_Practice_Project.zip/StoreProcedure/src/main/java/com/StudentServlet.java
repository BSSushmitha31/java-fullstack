package com;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/StudentServlet")
public class StudentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String jdbcUrl = "jdbc:mysql://localhost:3306/mydatabase";
        String username = "root";
        String password = "root";

        try {
            // Step 1: Register the JDBC driver (if necessary)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Step 2: Open a connection to the database
            Connection connection = DriverManager.getConnection(jdbcUrl, username, password);

            // Step 3: Call the stored procedure using a CallableStatement
            CallableStatement callableStatement = connection.prepareCall("{CALL GetStudents()}");
            ResultSet resultSet = callableStatement.executeQuery();

            // Display the retrieved data
            out.println("<html><body>");
            out.println("<h2>Student List:</h2>");
            out.println("<table>");
            out.println("<tr><th>ID</th><th>Name</th><th>Marks</th></tr>");
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                float marks = resultSet.getFloat("marks");
                out.println("<tr><td>" + id + "</td><td>" + name + "</td><td>" + marks + "</td></tr>");
            }
            out.println("</table>");
            out.println("</body></html>");

            // Step 4: Close the resources
            resultSet.close();
            callableStatement.close();
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}

