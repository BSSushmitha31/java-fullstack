package com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.*;
import java.util.logging.*;

@WebFilter("/DataInfo")
public class AuthenticateFilter implements Filter {

    private static final Logger LOGGER = Logger.getLogger(AuthenticateFilter.class.getName());

    public void init(FilterConfig config) throws ServletException {
        // Initialization code goes here if needed
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        response.setContentType("text/html");
        String uname = request.getParameter("txtuname");
        String pword = request.getParameter("txtpword");
        PrintWriter out = response.getWriter();

        if (uname.equalsIgnoreCase("Java") && pword.equals("eclipse@123")) {
            chain.doFilter(request, response);
        } else {
            LOGGER.log(Level.WARNING, "Invalid username or password");
            out.println("Invalid Username or password");
            RequestDispatcher dispatch = request.getRequestDispatcher("index.html");
            dispatch.include(request, response);
        }
    }

    public void destroy() {
        // Cleanup code goes here if needed
    }
}
