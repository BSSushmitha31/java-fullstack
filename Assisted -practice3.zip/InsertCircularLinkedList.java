package Assignment3;
public class InsertCircularLinkedList {
    private Node head;

    private static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    public void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            newNode.next = newNode;
            head = newNode;
        } else if (data <= head.data) {
            newNode.next = head.next;
            head.next = newNode;
            int temp = head.data;
            head.data = newNode.data;
            newNode.data = temp;
        } else {
            Node current = head;
            while (current.next != head && data > current.next.data) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    public void display() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }

    public static void main(String[] args) {
        InsertCircularLinkedList list = new InsertCircularLinkedList();
        list.insert(70);
        list.insert(30);
        list.insert(10);
        list.insert(40);
        list.insert(50);

        System.out.println("Sorted Circular Linked List:");
        list.display();

        int newElement = 35;
        System.out.println("Inserting a new element: " + newElement);
        list.insert(newElement);

        System.out.println("Circular Linked List after insertion:");
        list.display();
    }
}
