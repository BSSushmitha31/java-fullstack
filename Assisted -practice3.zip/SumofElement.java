package Assignment3;

import java.util.Scanner;

public class SumofElement {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        System.out.print("Enter the value of n: ");
	        int n = scanner.nextInt();

	        int[] numbers = new int[n];

	        System.out.println("Enter the elements:");
	        for (int i = 0; i < n; i++) {
	            numbers[i] = scanner.nextInt();
	        }

	        System.out.println("Enter the value of L: ");
	        int L = scanner.nextInt();

	        System.out.println("Enter the value of R: ");
	        int R = scanner.nextInt();

	        int sum = calculateSumInRange(numbers, L, R);
	        System.out.println("Sum of elements within the range of L and R is: " + sum);

	        scanner.close();
	    }

	    public static int calculateSumInRange(int[] numbers, int L, int R) {
	        if (L < 0 || R >= numbers.length || L > R) {
	            throw new IllegalArgumentException("Invalid range");
	        }

	        int sum = 0;
	        for (int i = L; i <= R; i++) {
	            sum += numbers[i];
	        }

	        return sum;
	    }
	}
