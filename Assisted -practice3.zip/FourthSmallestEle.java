package Assignment3;

import java.util.Arrays;
import java.util.List;

public class FourthSmallestEle {
	    public static void main(String[] args) {
	        List<Integer> numbers = Arrays.asList(8,5,0,1,2,7,3);
	        int fourthSmallest = smallest(numbers);
	        System.out.println("The fourth smallest element is: " + fourthSmallest);
	    }

	    public static int smallest(List<Integer> numbers) {
	        if (numbers.size() < 4) {
	            throw new IllegalArgumentException("List should have atleast 4 elements");
	        }
	        Integer[] arr = numbers.toArray(new Integer[0]);
	        Arrays.sort(arr);
	        return arr[3];
	    }
	}


