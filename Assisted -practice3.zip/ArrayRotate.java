package Assignment3;

import java.util.Arrays;

public class ArrayRotate {
	  public static void main(String[] args) {
	        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
	        
	        int steps = 5;
	        
	        System.out.println("Array:");
	        System.out.println(Arrays.toString(arr));
	        
	        rightRotateArray(arr, steps);
	        
	        System.out.println("\nAfter Right Rotation:");
	        System.out.println(Arrays.toString(arr));
	    }
	    
	    public static void rightRotateArray(int[] arr, int steps) {
	        int length = arr.length;
	        int[] temp = new int[length];
	        
	        for (int i = 0; i < length; i++) {
	            int newPosition = (i + steps) % length;
	            temp[newPosition] = arr[i];
	        }
	        
	        System.arraycopy(temp, 0, arr, 0, length);
	    }
}
