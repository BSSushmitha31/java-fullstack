package Assignment3;
import java.util.LinkedList;

public class DeleteSinglyLinked {
    public static void main(String[] args) {
        LinkedList<Integer> linkedList = new LinkedList<>();

        linkedList.add(1);
        linkedList.add(2);
        linkedList.add(3);
        linkedList.add(4);
        linkedList.add(5);

        System.out.println("LinkedList:");
        System.out.println(linkedList);

        int key = 3;
      
        // Find and delete
        boolean removed = linkedList.removeFirstOccurrence(key);

        if (removed) {
            System.out.println(key + " Find and Deleted successfully");
        } else {
            System.out.println( key + " not found in the list");
        }

        System.out.println("LinkedList after deletion:");
        System.out.println(linkedList);
    }
}
