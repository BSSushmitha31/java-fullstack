package PracticeProject;

import java.util.Scanner;

public class ArithmeticCalculator {
	
	 public static void main(String[] args) {
		 Scanner scanner = new Scanner(System.in);
	        
	        while (true) {
		        System.out.println("Arithmetic Calculator");
		        System.out.println("1. Add");
		        System.out.println("2. Subtract");
		        System.out.println("3. Multiply");
		        System.out.println("4. Divide");
		        System.out.println("5. Exit");
		        System.out.print("Enter your choice: ");
	            int choice = scanner.nextInt();
	            
	            if (choice == 5) {
	                System.out.println("Exiting from calculator");
	                break;
	            }
	            
	            System.out.print("Enter the first number: ");
	            double num1 = scanner.nextDouble();
	            System.out.print("Enter the second number: ");
	            double num2 = scanner.nextDouble();
	            
	            switch (choice) {
	                case 1:
	                    double add = num1 + num2;
	                    System.out.println("Additon of 2 numbers : " + add);
	                    break;
	                    
	                case 2:
	                    double sub = num1 - num2;
	                    System.out.println("Subtraction of 2 numbers : " + sub);
	                    break;
	                    
	                case 3:
	                    double mul = num1 * num2;
	                    System.out.println("Multiplecation of 2 numbers : " + mul);
	                    break;
	                    
	                case 4:
	                    if (num2 == 0) {
	                        System.out.println("Division by zero is not posiible");
	                    } else {
	                        double div = num1 / num2;
	                        System.out.println("Division of 2 numbers : " + div);
	                    }
	                    break;
	                default:
	                    System.out.println("Invalid choice..... Please try again....");
	            }
	            
	            System.out.println();
	        }
	       
	    }
	    
	   

}
