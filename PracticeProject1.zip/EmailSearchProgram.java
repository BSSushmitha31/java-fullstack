package PracticeProject;

import java.util.Scanner;

import java.util.Arrays;

public class EmailSearchProgram {
    public static void main(String[] args) {
        // Array of email id's
        String[] emails = { "sushmitha@gmail.com", "anusha@gmail.com", "suresh@gmail.com", "sujatha@gmail.com" };

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter email id to search: ");
        String searchEmail = scanner.nextLine();

        // to perform the search
        boolean find = false;
        for (String email : emails) {
            if (email.equalsIgnoreCase(searchEmail)) {
                find = true;
                break;
            }
        }

        // to display the result
        if (find) {
            System.out.println("Email id find");
        } else {
            System.out.println("Email id not find");
        }
    }
}