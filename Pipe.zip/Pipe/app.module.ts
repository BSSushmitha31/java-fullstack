import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { DateExampleComponent } from './date-example/date-example.component'; // Import the component here

@NgModule({
  declarations: [AppComponent, DateExampleComponent], // Add the DateExampleComponent to the declarations
  imports: [BrowserModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
