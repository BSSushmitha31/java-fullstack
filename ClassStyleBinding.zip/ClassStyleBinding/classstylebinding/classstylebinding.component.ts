import { Component } from '@angular/core';

@Component({
  selector: 'app-classstylebinding',
  templateUrl: './classstylebinding.component.html',
  styleUrls: ['./classstylebinding.component.css']
})
export class ClassstylebindingComponent {
  isButtonDisabled: boolean = true;

  // 5.3.2 Implementing class binding
  isMessageHighlighted: boolean = true;

  // 5.3.3 Implementing style binding
  boxWidth: number = 100;
  boxHeight: number = 100;
  boxColor: string = 'blue';
}
