import { Component } from '@angular/core';

@Component({
  selector: 'app-binding-eg',
  templateUrl: './binding-eg.component.html',
  styleUrls: ['./binding-eg.component.css']
})
export class BindingEgComponent {

}
