import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BindingEgComponent } from './binding-eg.component';

describe('BindingEgComponent', () => {
  let component: BindingEgComponent;
  let fixture: ComponentFixture<BindingEgComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [BindingEgComponent]
    });
    fixture = TestBed.createComponent(BindingEgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
