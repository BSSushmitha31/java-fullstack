package com;

import org.junit.jupiter.api.RepeatedTest;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;

@RunWith(JUnitPlatform.class)
public class RepeatedTest {

    @RepeatedTest(1000)
    public void test() {
        System.out.println("Test called..");
    }
}
