package com.example.UserAuthentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assisted5ProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
