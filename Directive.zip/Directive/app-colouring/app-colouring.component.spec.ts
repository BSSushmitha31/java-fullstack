import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AppColouringComponent } from './app-colouring.component';

describe('AppColouringComponent', () => {
  let component: AppColouringComponent;
  let fixture: ComponentFixture<AppColouringComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AppColouringComponent]
    });
    fixture = TestBed.createComponent(AppColouringComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
