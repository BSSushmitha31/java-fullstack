package AssistedPractice2;

public class ThrowsFinallyThrow {
	
	//Throw example
//	    public static void main(String[] args) {
//	        try {
//	            int result = 10/0;
//	            System.out.println("Result: " + result);
//	        } catch (ArithmeticException e) {
//	            System.out.println("ArithmeticException: " + e.getMessage());
//	        }
//	    }
//
//	    public static int divide(int a, int b) {
//	        if (b == 0) {
//	            throw new ArithmeticException("Not possible division by zero");
//	        }
//	        return a / b;
//	    }
//	}

	
	//Throws example
	
//	    public static void main(String[] args) {
//	        try {
//	            int result = 10/0;
//	            System.out.println("Result: " + result);
//	        } catch (ArithmeticException e) {
//	            System.out.println("ArithmeticException: " + e.getMessage());
//	        }
//	    }
//
//	    public static int divide(int a, int b) throws ArithmeticException {
//	        if (b == 0) {
//	            throw new ArithmeticException("Not possible division by zero");
//	        }
//	        return a / b;
//	    }
//	}
//

	//finally example
	
	    public static void main(String[] args) {
	        try {
	            int result = 10/0;
	            System.out.println("Result: " + result);
	        } catch (ArithmeticException e) {
	            System.out.println("ArithmeticException: " + e.getMessage());
	        } finally {
	            System.out.println("Finally block executed");
	        }
	    }

	    public static int divide(int a, int b) {
	        try {
	            return a / b;
	        } catch (ArithmeticException e) {
	            throw new ArithmeticException("Division by zero is not possible");
	        }
	    }
	}

