package AssistedPractice2;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FileRead {

		    public static void main(String[] args) {
	       
	        String filePath = "C:\\Users\\Anusha\\Desktop\\file\\filetxt.txt";
	        
	        try {
	            
	            FileReader fileReader = new FileReader(filePath);

	            BufferedReader bufferedReader = new BufferedReader(fileReader);
	            
	            String line;
	            
	            // Read each line from the file until the end is reached
	            while ((line = bufferedReader.readLine()) != null) {
	                // Process the line (print it in this example)
	                System.out.println(line);
	            }
	            
	            // Close the BufferedReader
	            bufferedReader.close();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }

}
