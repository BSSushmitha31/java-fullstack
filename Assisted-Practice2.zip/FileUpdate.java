package AssistedPractice2;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class FileUpdate {

	    public static void main(String[] args) 
	    {
	        String filePath = "C:\\Users\\Anusha\\Desktop\\file\\filetxt.txt";
	        
	        try {
	            FileWriter fileWriter = new FileWriter(filePath, true);
	            
	            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
	            
	            // Write new content to the file
	            bufferedWriter.write("New content");
	            bufferedWriter.close();
	            System.out.println("File updated successfully.");
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
}
