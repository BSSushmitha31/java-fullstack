package AssistedPractice2;



public class SleepWait {
	
	    private static final Object LOCK = new Object();
 
	    static class SleepThread implements Runnable {
	        @Override
	        public void run() {
	            try {
	                Thread.sleep(200); // Sleep for 2 seconds
	                System.out.println("Sleep_thread woke up");
	            } catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	        }
	    }

	    static class WaitThread implements Runnable {
	        @Override
	        public void run() {
	            synchronized (LOCK) {
	                try {
	                    LOCK.wait(200); // Wait for 2 seconds
	                    System.out.println("Wait_thread woke up");
	                } catch (InterruptedException e) {
	                    e.printStackTrace();
	                }
	            }
	        }
	    }
	    public static void main(String[] args) throws InterruptedException {
	        Thread sleepThread = new Thread(new SleepThread());
	        Thread waitThread = new Thread(new WaitThread());

	        sleepThread.start();
	        waitThread.start();
	    }
	}



