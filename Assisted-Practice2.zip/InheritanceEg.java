package AssistedPractice2;

	class Animal {
	    protected String name;

	    public Animal(String name) {
	        this.name = name;
	    }

	    public void sound() {
	        System.out.println("Animal makes a sound");
	    }
	}

	class Cat extends Animal {
	    public Cat(String name) {
	        super(name);
	    }

	    public void sound() {
	        System.out.println(name + " sounds like meow");
	    }
	}

	class Dog extends Animal {
	    public Dog(String name) {
	        super(name);
	    }

	    public void sound() {
	        System.out.println(name + " sounds like bark");
	    }
	}

	public class InheritanceEg {
	    public static void main(String[] args) {
	        Cat cat = new Cat("cat");
	        cat.sound();

	        Dog dog = new Dog("dog");
	        dog.sound();
	    }
}


