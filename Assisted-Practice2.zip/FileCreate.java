package AssistedPractice2;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileCreate {
	
	    public static void main(String[] args) throws IOException {
	        String filePath = "C:\\Users\\Anusha\\Desktop\\file\\filetxt.txt";
	        
	        File file = new File(filePath);
	        
	        createFileUsingFileOutputStreamClass(file);
	        
	        System.out.println("File created successfully.");
	    }
	    
	    private static void createFileUsingFileOutputStreamClass(File file) throws IOException 
	    {
	      
	        FileOutputStream fos = new FileOutputStream(file);
	        fos.close();
	    }
}



