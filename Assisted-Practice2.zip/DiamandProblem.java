package AssistedPractice2;

	interface Diamand
	{
		int x=20;
	}
	interface Demo
	{
		void test();
	}
	
	class Tester implements Diamand,Demo
	{
		public void test()
		{
			System.out.println("hello");
		}
		void cool()
		{
			System.out.println("hiiii");
		}
	}
	public class DiamandProblem 
	{
		public static void main(String[] args) {
			Tester t1 = new Tester();
			t1.test();
			t1.cool();
			System.out.println(t1.x);
	}

}
