package AssistedPractice2;

	abstract class Shape2 {
	    public abstract void draw();
	}

	class Triangle extends Shape {
	    @Override
	    public void draw() {
	        System.out.println("Drawing a Triangle");
	    }
	}

	class Squar extends Shape {
	    @Override
	    public void draw() {
	        System.out.println("Drawing a Squar");
	    }
	}

	public class AbstractionEg {
	    public static void main(String[] args) {
	        Shape triangle = new Triangle();
	        triangle.draw();

	        Shape squar = new Squar();
	        squar.draw();
	    }
}


