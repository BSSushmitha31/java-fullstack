package AssistedPractice2;

import java.io.File;

public class FileDelete {
	
		    public static void main(String[] args) {
	        try {
	           	    String filePath = "C:\\Users\\Anusha\\Desktop\\file\\filetxt.txt";
	                File file = new File(filePath);

		            // Check if the file exists
		            if (file.exists()) {
		                file.delete();
		                System.out.println("File deleted successfully.");
		            } else {
	                System.out.println("File does not exist.");
	            }
	        } catch (Exception e) {
	            System.out.println("An error occurred while deleting the file: " + e.getMessage());
	        }
	    }
	}
