package AssistedPractice2;

	class Student{
	    String name;
	    int age;

	    void displayInfo() {
	        System.out.println("Name: " + name);
	        System.out.println("Age: " + age);
	    }
	}

	public class ClassObject {
	    public static void main(String[] args) {
	        // Creating objects of the Student class
	    	Student student1 = new Student();
	    	Student student2 = new Student();

	        // Assigning values to object properties
	    	student1.name = "Sushma";
	    	student1.age = 25;

	    	student2.name = "Anu";
	    	student2.age = 23;

	        // Displaying information using object methods
	        System.out.println("\nStudent 1:");
	        student1.displayInfo();

	        System.out.println("\nStudent 2:");
	        student2.displayInfo();
	    }
}
