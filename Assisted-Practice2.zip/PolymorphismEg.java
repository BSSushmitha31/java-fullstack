package AssistedPractice2;

	class Shape {
	    public void draw() {
	        System.out.println("Drawing a shape");
	    }

	    public void draw(String color) {
	        System.out.println("Drawing a shape with color: " + color);
	    }
	}

	class Circle extends Shape {
	    @Override
	    public void draw() {
	        System.out.println("Drawing a circle");
	    }
	}

	class Rectangle extends Shape {
	    @Override
	    public void draw() {
	        System.out.println("Drawing a rectangle");
	    }
	}

	public class PolymorphismEg {
	    public static void main(String[] args) {
	        Shape shape1 = new Circle();
	        Shape shape2 = new Rectangle();

	        shape1.draw();  
	        shape1.draw("Red");             
	        shape2.draw();                  
	        shape2.draw("Blue");            
	    }
}


