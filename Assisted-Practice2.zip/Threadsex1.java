package AssistedPractice2;

//class MyThread extends Thread {
//    @Override
//    public void run() {
//        System.out.println("extending the thread class");
//    }
//}
//
//public class Threadsex1 {
//
//	public static void main(String[] args) {
//		 //extending Thread class
//        MyThread thread = new MyThread();
//        thread.start();		
//	}
//
//}

//implement runnable
class Hi implements Runnable
{
	public void run()
	{
		for(int i=1; i<=5 ; i++)
		{
		System.out.println("helllooooo");
		}
		}
}
public class Threadsex1 
{

	public static void main(String[] args) 
	{
		Runnable obj1 = new Hi();
		Thread t1 = new Thread(obj1);
		t1.start();
	}
}
