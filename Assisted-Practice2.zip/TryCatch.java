package AssistedPractice2;

public class TryCatch {

	public static void main(String[] args) {
		try  
        {  
        int result=10/0; //it may throw exception   
        }  
            //catch handling the exception  
        catch(ArithmeticException e)  
        {  
            System.out.println(e);  
        }  
        System.out.println("Hello");  
    }  
	}


