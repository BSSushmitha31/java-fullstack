package AssistedPractice2;

public class ExceptionHandling 
{

		public static void main(String[] args) 
		{
	        try {
	            int result = 10/0;
	            System.out.println("Result: " + result);
	        } catch (ArithmeticException e) {
	            System.out.println("ArithmeticException: " + e.getMessage());
	        } finally {
	            System.out.println("Finally block executed");
	        }

	        System.out.println("Program continues after exception handling");
	    }

	    public static int divide(int a, int b) 
	    {
	        try {
	            return a / b;
	        } catch (ArithmeticException e) {
	            throw new ArithmeticException("Division by zero is not possible");
	        }
	    }
}


