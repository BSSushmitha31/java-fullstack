package AssistedPractice2;

	class Student1 {
	    private String name;
	    private int age;

	    public void setName(String name) {
	        this.name = name;
	    }

	    public String getName() {
	        return name;
	    }

	    public void setAge(int age) {
	        if (age >= 0) {
	            this.age = age;
	        } else {
	            System.out.println("Invalid age");
	        }
	    }

	    public int getAge() {
	        return age;
	    }
	}

	public class EncapsulationEg {
	    public static void main(String[] args) {
	    	Student1 student1 = new Student1();
	    	student1.setName("Sush");
	    	student1.setAge(25);

	        System.out.println("Student Name: " + student1.getName());
	        System.out.println("Student Age: " + student1.getAge());
	    }
	}



