package assignment4;

public class QuickSort {
	public static void main(String[] args) {
		int data[]= {8,7,2,1,0,9,6};
		quickSort(data,0,data.length-1);
		for(int i=0;i<data.length;i++)
			System.out.print(data[i]+" ");

	}

	private static void quickSort(int[] data, int low, int high) {
		if(low<high) {
			
			int pivot=partition(data,low,high);
			quickSort(data,low,pivot-1);
			quickSort(data,pivot+1,high);
		}
		
	}

	private static int partition(int[] data, int low, int high) {
		
		int pivot=data[high];
		int i=low-1;
		for(int j=low;j<high;j++) 
		{
			if(data[j]<=pivot) 
			{
				i++;
				int temp=data[i];
				data[i]=data[j];
				data[j]=temp;
			}
		
		}
		int temp=data[i+1];
		data[i+1]=data[high];
		data[high]=temp;
		return i+1;
	}
}
